SVGE Brand Pack
================

Sree Veeranjaneya Green Energy Private Limited
CIN U35101AP2024PTC115061
Thatipadu, Vizianagaram, Andhra Pradesh, India

The mark
--------
A forest-green leaf with a saffron flame on a paper field. The leaf is the
feedstock; the flame is what we turn it into. Use the mark on an off-white
or brand-green background; for dark backgrounds use the inverted PNG.

Palette
-------
Forest    #1B5E20
Saffron   #E65100
Gold      #FFB300
Paper     #FAFAF7
Ink       #0A0A0A
Slate     #2A2D34

Typography
----------
Display   Libre Bodoni
Body      Public Sans
Mono      IBM Plex Mono

Use
---
Editorial reuse with attribution is permitted. Don't recolour the mark,
distort its proportions, or place it on a busy photograph without
contrast scrim.

Press contact: svge.india@gmail.com
Press kit on the web: https://kalasagar.github.io/sree-veeranjaneya-green-energy/press/
